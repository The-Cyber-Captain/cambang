
# Godot Boundary Verification Scenes

Status: Dev Note  
Purpose: Documents the Godot-side scenes used to verify runtime publication behaviour.

## Goal

These scenes verify behaviour observable from the Godot boundary including:

- restart semantics
- snapshot publication ordering
- tick-bounded coalescing
- NIL-before-baseline behaviour

## Provider Selection

Scenes normally use **SyntheticProvider** to produce deterministic behaviour.

## Test Philosophy

Native tools verify internal runtime correctness.

Godot scenes verify:

- boundary stability
- snapshot immutability
- restart behaviour
- publication ordering

## Output Discipline

Scenes must flush output before quitting so that PASS/FAIL messages are reliably captured by automated runs.
