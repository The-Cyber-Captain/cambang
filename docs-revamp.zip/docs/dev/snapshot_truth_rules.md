
# Snapshot Truth Rules

Status: Dev Note  
Supplements: `state_snapshot.md`

This document provides review guidance for enforcing the snapshot truth
rules defined in `state_snapshot.md`. It is not a second source of
architectural truth.

## Principle

Snapshot fields must represent **actual retained runtime truth**.

They must never contain:

- fabricated bootstrap values
- guessed provider state
- predicted future state

## When Zero Is Correct

Fields may legitimately be zero when:

- the runtime has not yet observed the value
- the provider has not reported the information
- the resource does not exist

## Invalid Patterns

Examples of invalid snapshot behaviour:

- populating format fields before the provider reports them
- inventing topology identifiers
- guessing warm retention values

## Adding New Snapshot Fields

When adding fields:

1. The value must originate from retained runtime state.
2. The snapshot must remain immutable after publication.
3. Unknown values must remain unknown instead of fabricated.
