# Maintainer Tools

This document describes the command-line utilities, Godot-side
verification scenes, and truth-discipline rules used by maintainers to
validate internal invariants, provider behaviour, boundary semantics,
and selected performance characteristics of the CamBANG runtime.

These tools are **not user-facing applications** and are not intended to
ship as part of production builds. They exist to help maintainers validate
correctness while developing the runtime.

Most tools are **opt-in build artifacts** and will not appear in normal
build outputs unless explicitly requested.

---

## 1. Tool categories

Maintainer tools fall into three broad categories.

| Category | Purpose |
|---|---|
| Smoke test | Minimal sanity check ensuring the core runtime spine operates correctly |
| Verification | Deterministic validation of specific runtime invariants |
| Benchmark | Performance measurement utilities |

---

## 2. Tool overview

| Tool / asset | Purpose | Category |
|---|---|---|
| `core_spine_smoke` | Minimal Core runtime invariant validation using the stub provider | Smoke test |
| `synthetic_timeline_verify` | Deterministic verification of SyntheticProvider timeline behaviour and Core registry truth | Verification |
| `phase3_snapshot_verify` | Focused verification for snapshot/native-object/publication semantics | Verification |
| `restart_boundary_verify` | Deterministic verification of the CamBANGServer stop/start boundary contract | Verification |
| `provider_compliance_verify` | Deterministic provider-contract verification using Stub and Synthetic only | Verification |
| `windows_mf_runtime_validate` | Opt-in Windows Media Foundation runtime validation against real hardware | Verification |
| `pattern_render_bench` | Pattern renderer performance benchmark | Benchmark |
| Godot boundary verification scenes | Validation of the Godot-facing runtime boundary | Verification |

---

## 3. Terminology

### Smoke test

A minimal executable that validates the runtime spine:

- core runtime start
- provider registration
- state publication
- basic teardown

Smoke tests should remain **deterministic and provider-independent**.
They must not depend on real hardware.

### Verification tool

A deterministic executable used to validate specific internal invariants
or subsystem behaviour.

Verification tools should:

- be deterministic
- avoid platform hardware dependencies where possible
- produce a clear pass / fail result
- run quickly

### Platform runtime validation

A maintainer tool that validates a platform-backed provider against real
OS APIs and, where applicable, real hardware.

Unlike deterministic verifiers, platform validation may depend on:

- device presence
- driver behaviour
- negotiated formats
- local machine state

Platform runtime validation must remain explicitly opt-in.

### Benchmark

A performance measurement utility.

Benchmarks do not validate correctness; they measure throughput,
latency, or resource usage.

---

## 4. Provider validation layering

Provider correctness is validated in **two layers**:

1. deterministic provider-contract verification
2. platform-backed runtime validation

This layering matches the architecture rules defined in:

- `docs/provider_architecture.md`
- `docs/core_runtime_model.md`

Deterministic provider validation must not rely on physical hardware.
Platform validation is performed separately using explicit tools.

The terse provider-audit checklist remains separately documented in:

```text
docs/dev/provider_compliance_checklist.md
```

---

## 5. `provider_compliance_verify`

**Category:** Verification tool

### Purpose

`provider_compliance_verify` validates the provider contract and lifecycle
rules using deterministic providers only.

It exercises:

- `StubProvider`
- `SyntheticProvider`

This is the primary maintainer check for provider-contract rules such as:

- serialized provider → core callback delivery
- lifecycle ordering correctness
- native-object create / destroy reporting
- non-lossy lifecycle/native-object/error delivery
- deterministic shutdown sequencing
- synthetic ordering and timeline invariants

### What it does not do

It deliberately does **not**:

- enumerate physical cameras
- open platform-backed devices
- validate real Media Foundation or other platform APIs
- exercise hardware-driven asynchronous device callbacks

Those concerns belong to platform validation tools.

### Build and usage

Typical build form:

```text
scons smoke=1 smoke
```

Usage:

```text
./out/provider_compliance_verify.exe
```

Expected result:

```text
PASS provider_compliance_verify
```

---

## 6. `restart_boundary_verify`

**Category:** Verification tool

### Purpose

`restart_boundary_verify` is the authoritative deterministic verifier for
the CamBANGServer stop/start boundary contract.

It directly validates the **NIL-before-baseline** rule across a full
stop → restart cycle.

This tool exists because restart behaviour must be provable independently
of Godot-scene scheduling behaviour.

### Contract validated

The verifier enforces these runtime rules:

1. after completed `CamBANGServer.stop()`, the public snapshot is `NIL`
2. after a subsequent `start()`, `get_state_snapshot()` remains `NIL`
   until the first published snapshot of the new generation
3. the first post-restart publish yields a valid snapshot
4. stale publications from the previous generation do **not** repopulate
   the public snapshot
5. restart initiated from callback-context-equivalent execution remains safe

### Usage

```text
./out/restart_boundary_verify.exe
```

Expected output shape:

```text
step 0 OK
step 1 OK
step 2 OK
step 3 OK
step 4 OK
OK: restart_boundary_verify passed
```

Any failure indicates a regression in Godot-boundary snapshot exposure.

---

## 7. `windows_mf_runtime_validate`

**Category:** Verification tool (platform-backed)

### Purpose

`windows_mf_runtime_validate` validates the Windows Media Foundation
provider under real asynchronous hardware-backed execution.

It exercises:

- device enumeration
- real device open
- stream start / stop
- shutdown behaviour

This complements deterministic provider verification but does not replace it.

### Build and usage

```text
scons platform_validate=1 windows_mf_runtime_validate
./out/windows_mf_runtime_validate.exe --real-hardware
```

Expected high-level behaviour:

1. enumerate camera
2. open device
3. negotiate media type
4. start stream
5. shut down cleanly

---

## 8. Other native tools

### `core_spine_smoke`

Minimal runtime sanity check validating the Core runtime spine using the
stub provider.

This tool verifies that runtime can:

- start
- process provider events
- publish state
- shut down cleanly

Modes:

| Mode | Purpose |
|---|---|
| default | baseline runtime validation |
| `--stress` | lifecycle churn and queue-pressure testing |

### `synthetic_timeline_verify`

Validates deterministic behaviour of the SyntheticProvider timeline and
its interaction with the core lifecycle registry.

Common scenario shapes include:

- basic lifecycle
- invalid sequence
- catch-up / stress timing

Validation targets include:

- deterministic frame scheduling
- lifecycle event emission
- registry truthfulness under timeline-driven facts

### `phase3_snapshot_verify`

Focused verifier for snapshot/publication correctness.

It may cover areas such as:

- detached-root visibility semantics
- retirement / removal observability
- topology-version transitions
- timestamp semantics
- delivered vs dropped accounting

It intentionally does **not** replace restart-boundary verification.

### `pattern_render_bench`

Measures pattern-renderer throughput and memory-bandwidth characteristics.

Benchmarks **do not** assert correctness.

---

## 9. Godot boundary verification scenes

In addition to the native CLI tools, the repository includes Godot-side
boundary verification scenes.

These scenes validate the observable contract between:

```text
Core Runtime → Snapshot Publication → CamBANGServer → Godot consumers
```

They are development diagnostics and are **not** product UI.

These scenes intentionally use `SyntheticProvider` as the deterministic
runtime driver even when validating builds configured for other providers.

They complement the CLI tools:

| Layer | Validation |
|---|---|
| CLI tools | Core invariants, provider contracts |
| Godot scenes | Godot-facing runtime boundary behaviour |

### Purpose

The scenes exercise the chain:

```text
Provider
↕
Core Runtime
↕
Snapshot Publication
↕
CamBANGServer
↕
Godot Consumers
```

They verify that the Godot-visible runtime boundary remains:

- deterministic
- crash-free
- semantically correct
- safe for polling and signal consumption

### Scene set

#### `60_restart_boundary_abuse`

Verifies restart semantics.

Checks:

- snapshot becomes `NIL` after stop
- no stale snapshot appears before new baseline
- first publish of a new generation is `(gen+1, 0, 0)`

Expected output:

```text
OK: godot restart boundary abuse PASS
```

#### `61_tick_bounded_coalescing_abuse`

Verifies tick-bounded publication.

Checks:

- at most one `state_published` signal per Godot tick
- `version` remains contiguous
- `topology_version` changes only when observable topology changes

Expected output:

```text
OK: godot tick-bounded coalescing abuse PASS
```

#### `62_snapshot_polling_immutability_abuse`

Verifies snapshot immutability and polling safety.

Checks:

- cached snapshots remain readable
- cached snapshots do not mutate
- polling and signals behave consistently

Expected output:

```text
OK: godot snapshot polling/immutability abuse PASS
```

#### `63_snapshot_observer_minimal`

A minimal observer scene for diagnostics.

Typical displayed fields include:

- generation
- version
- topology_version
- device count
- stream count
- frame counters

Expected output:

```text
OK: godot snapshot observer minimal PASS
```

### Running rule

Scenes are intended to run individually from the Godot project.

Each scene:

1. starts the runtime
2. optionally triggers a deterministic scenario
3. performs boundary assertions
4. prints a final PASS or FAIL line
5. exits automatically

### Final output rule (test-harness hardening)

Any self-running Godot verification scene that prints a final result line
such as:

```text
OK: ...
FAIL: ...
```

must **not** call:

```text
get_tree().quit()
```

immediately in the same call stack.

Instead the scene must:

1. print the final result line
2. schedule a deferred exit
3. quit after a short delay (for example two frames or ~50 ms)

This improves output reliability during shutdown without weakening assertions.

---

## 10. Snapshot truth rules

Snapshot fields must always represent **real runtime truth**.

If authoritative runtime truth does not exist for a field, the snapshot
must publish `0` or an empty value rather than fabricate a placeholder.

### Acceptable states

1. runtime truth exists and is projected
2. runtime truth does not yet exist and the snapshot publishes `0`
3. retention or plumbing exists but the value remains unset until real truth arrives

### Forbidden pattern

The runtime must never fabricate bootstrap values for snapshot fields.

Examples of problematic patterns:

- `ensure_camera_spec_version(hardware_id, 1)`
- `reset_for_generation(1)`
- `default_version = 1`
- `seed_if_missing()`

A non-zero value implies that real runtime truth exists.

### Code-review rule

When reviewing snapshot fields, ask:

1. where does this value become true?
2. what event authorizes that truth?
3. what happens if that event never occurs?

If code fabricates a value in that case, the snapshot field is incorrect.

## Snapshot Truth Rules

Snapshot tests verify that the runtime's published state matches the
actual state of devices and providers.

The following rules must always hold.

Rule 1 — Truthful Presence
If a device is physically present and discoverable, the runtime
snapshot must report it as present.

Rule 2 — Truthful Absence
If a device disappears or fails, the snapshot must reflect the
disappearance without delay once detected.

Rule 3 — No Synthetic Repair
Providers must not fabricate state transitions to satisfy an
expected snapshot.

Rule 4 — Stable Identity
Device identifiers must remain stable across snapshots for the
lifetime of the device.

Rule 5 — Snapshot Consistency
A snapshot must represent a coherent state of the system at the
time of publication.

Purpose

These rules prevent drift between hardware reality and the runtime
model and ensure that verification tools detect provider misbehavior
rather than masking it.
---

## 11. Design principles

Maintainer tools follow these rules:

1. deterministic verification tools should remain hardware-independent wherever possible
2. platform validation must be explicit and opt-in
3. smoke tests should remain minimal and fast
4. verification tools should produce clear pass / fail results
5. benchmarks measure performance but do not assert correctness
6. Godot boundary scenes complement, but do not replace, native deterministic verifiers
7. snapshot-truth rules apply equally to runtime code, verifiers, and diagnostic expectations
